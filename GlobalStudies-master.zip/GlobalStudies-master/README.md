# GlobalStudies
Description:
This is for a global studies project. I will be making a project on [topic].

Sources:
